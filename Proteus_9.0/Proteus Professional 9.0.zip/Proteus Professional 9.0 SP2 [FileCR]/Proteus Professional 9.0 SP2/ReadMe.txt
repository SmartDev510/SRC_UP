                                               
1. Use LicenseManager.exe install license.lxk
2. Copy version.dll to Proteus install directory(C:\Program Files\Labcenter Electronics\Proteus 9 Professional\Bin)
3. All done!